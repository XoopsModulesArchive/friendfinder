<?
#################################################################################
# Friend Finder for Xoops 1.3.x and Xoops 2.xx Version 3.1 beta                 #
#                                                                               #
# 			Copyright 2003 by eagle81						  #
#													  #
# Manuel Caballero	 	friendfinder@dancepartner.net				  #
# Module Homepage:		http://www.dancepartner.net				  #
#													  #
# Please report bugs and new feature request at modcentral.com friendfinder	  #
# forum or via mail frienfinder@dancepartner.net  					  #
#													  #
# Copyright for this langfile									  #
# Lanuage:			French								  #
# Name:				lcnslipe lcnslipe@aol.com				  #
# Homepage:			http://www.visioncms.fr.st					  #
#													  #
#                                                                               #
# Last modification:            2002-11-11						  #
#                                                                               #
# Initialy this script is based on phpMeet from                                 #
# Jeremy Ross 					webmaster@phprank.com                 #
# Script design  : PhpMeet  	Copyright 2002 -                                  #
# Created 15/01/02              Last Modified 15/01/02                          #
# Scripts Home                  http://www.jrscripts.com                        #
#													  #
# First Xoops Versions from:                   						  #
#                                                                               #
# Xoops-RC2 French Version  :   jokerman@free.fr                                #
# Web Home                  :   http://www.webetfric.com                        #
#                                                                               #
# Xoops-RC2 English Version :   webmaster@modscentral.com                    	  #
# Web Home                  :   http://www.modscentral.com                      #
#################################################################################

define("_FFBLOCKHEAD","Friendfinder");
define("_TEXTFFBLOCK","Friendfinder profil du jour");

?>